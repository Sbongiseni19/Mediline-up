document.addEventListener("DOMContentLoaded", function () {
    const displayData = document.getElementById("displayData");

    // Retrieve data from sessionStorage
    const jsonData = sessionStorage.getItem("formData");

    if (jsonData) {
        const data = JSON.parse(jsonData);

        // Display the collected data on the page
        displayData.innerHTML = `
            <p><strong>Name:</strong> ${data.name}</p>
            <p><strong>Surname:</strong> ${data.lname}</p>
            <p><strong>Email:</strong> ${data.email}</p>
            <p><strong>Adress:</strong> ${data.message}</p>
            <p><strong>Patient NO:</strong> 123456789876</p>
        `;
    } else {
        displayData.innerHTML = "<p>No data available.</p>";
    }
});
