document.addEventListener("DOMContentLoaded", function () {
    // Simulate loading progress
    simulateLoading();
});

function simulateLoading() {
    let progress = 0;
    const loadingText = document.getElementById('loadingText');
    const continueButton = document.getElementById('continueButton');

    function updateLoadingText() {
        loadingText.innerHTML = `Scanning Photo... ${progress}%`;
    }

    function setLoadingDone() {
        loadingText.innerHTML = 'Done!';
        continueButton.style.display = 'block';
    }

    function completeLoading() {
        setLoadingDone();
    
        // Stop the spinning animation by removing the 'spin' class
        const loader = document.getElementById('loader');
        loader.style.animation = 'none';
    
        // Add event listener for the continue button
        continueButton.addEventListener('click', function () {
            // Link to "New1.html" when the button is clicked
            window.location.href = 'Appform1.html';
        });
    }
    

    // Simulate loading progress from 0% to 100%
    const interval = setInterval(function () {
        if (progress < 100) {
            progress += 10; // You can adjust the increment value
            updateLoadingText();
        } else {
            clearInterval(interval);
            completeLoading();
        }
    }, 500); // You can adjust the interval time
}
