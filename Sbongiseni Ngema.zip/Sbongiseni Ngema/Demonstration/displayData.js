document.addEventListener("DOMContentLoaded", function () {
    const dataForm = document.getElementById("dataForm");

    dataForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const formData = new FormData(dataForm);
        const data = {};

        formData.forEach(function (value, key) {
            data[key] = value;
        });

        // Convert data object to JSON
        const jsonData = JSON.stringify(data);

        // Store data in sessionStorage
        sessionStorage.setItem("formData", jsonData);

        // Redirect to the display page
        window.location.href = "secondpage.html";
    });
});
